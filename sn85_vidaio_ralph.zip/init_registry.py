#!/usr/bin/env python3
"""
registry/init_registry.py
Initialises agent registry for SN85 Vidaio miner.
Usage: python registry/init_registry.py --task-type UPSCALING
"""
import argparse, json, os, hashlib
from datetime import datetime, timezone
from pathlib import Path

REGISTRY_DIR = Path(__file__).parent
ROOT = REGISTRY_DIR.parent


def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def init_all(task_type: str):
    REGISTRY_DIR.mkdir(exist_ok=True)

    # task_type.txt
    path = REGISTRY_DIR / "task_type.txt"
    if not path.exists():
        path.write_text(task_type)
        print(f"  task_type.txt: {task_type}")
    else:
        existing = path.read_text().strip()
        print(f"  task_type.txt: exists ({existing})")

    # agent_registry.jsonl
    path = REGISTRY_DIR / "agent_registry.jsonl"
    if not path.exists():
        path.write_text("")
        print("  agent_registry.jsonl: created")
    else:
        n = len([l for l in path.read_text().split("\n") if l.strip()])
        print(f"  agent_registry.jsonl: exists ({n} entries)")

    # progress.txt
    path = REGISTRY_DIR / "progress.txt"
    if not path.exists():
        path.write_text(
            f"# SN85 Vidaio Miner Agent Registry\n"
            f"# Initialised: {ts()}\n"
            f"# Task type: {task_type}\n"
            f"# Format: [RN] LOOP -- details\n\n"
            f"[R000] INIT -- task_type={task_type}. Run alignment checks before first round.\n"
        )
        print("  progress.txt: created")
    else:
        print(f"  progress.txt: exists ({(REGISTRY_DIR/'progress.txt').stat().st_size} bytes)")

    # shadow_accuracy.json
    path = REGISTRY_DIR / "shadow_accuracy.json"
    if not path.exists():
        path.write_text(json.dumps({
            "_comment": "Shadow evaluator state for SN85.",
            "task_type": task_type,
            "predicted_scores": [],
            "actual_scores": [],
            "shadow_accuracy": None,
            "last_updated_round": 0,
        }, indent=2))
        print("  shadow_accuracy.json: created")
    else:
        print("  shadow_accuracy.json: exists")

    # mutations.jsonl
    path = REGISTRY_DIR / "mutations.jsonl"
    if not path.exists():
        path.write_text("")
        print("  mutations.jsonl: created")

    # Check alignment tests
    test_path = ROOT / "scoring_alignment" / "sn85_vidaio_scoring_alignment.py"
    if test_path.exists():
        print(f"  Alignment tests: found")
    else:
        print(f"  Alignment tests: NOT found -- copy sn85_vidaio_scoring_alignment.py to scoring_alignment/")

    # Check vidaio-subnet repo
    vidaio_path = ROOT.parent / "vidaio-subnet"
    if vidaio_path.exists():
        scoring_path = vidaio_path / "services" / "scoring" / "scoring_function.py"
        if scoring_path.exists():
            h = hashlib.sha256(scoring_path.read_bytes()).hexdigest()[:12]
            hash_file = ROOT / "scoring_alignment" / ".scoring_function_hash"
            hash_file.parent.mkdir(exist_ok=True)
            hash_file.write_text(h)
            print(f"  vidaio-subnet repo: found (scoring_function.py hash: {h})")
        else:
            print(f"  vidaio-subnet repo: found but scoring_function.py missing")
    else:
        print(f"  vidaio-subnet repo: NOT found")
        print(f"  Run: git clone https://github.com/vidaio-subnet/vidaio-subnet.git {vidaio_path}")

    print()
    print("Registry ready. Start Claude Code: claude")
    print()
    print("First prompt:")
    print('  "Read CLAUDE.md, then run the session start checklist from Section 10."')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-type", choices=["UPSCALING", "COMPRESSION"],
                        default="UPSCALING", help="Your miner task type")
    args = parser.parse_args()
    print("=" * 60)
    print("SN85 Vidaio Agent Registry Initialiser")
    print("=" * 60)
    init_all(args.task_type)
    print("=" * 60)


if __name__ == "__main__":
    main()
