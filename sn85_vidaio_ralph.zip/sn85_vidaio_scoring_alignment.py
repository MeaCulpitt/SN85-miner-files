"""
sn85_vidaio_scoring_alignment.py

Scoring alignment tests for SN85 Vidaio -- video upscaling and compression.

SCOPE:
  Two completely separate scoring pipelines:
  1. UPSCALING: VMAF gate → PieAPP sigmoid-log transform → length score → exponential final
  2. COMPRESSION: VMAF gate + compression ratio → weighted composite

  This file tests the scoring mechanics you can verify locally without running
  the full validator stack (which requires FFmpeg VMAF, PieAPP model weights,
  and GPU hardware).

WHAT IS TESTABLE LOCALLY:
  CHECK 1: Response format -- optimized_video_url is non-empty and reachable
  CHECK 2: Task type declaration -- warrant_task matches what you actually process
  CHECK 3: VMAF gate thresholds -- understand the cutoffs that produce score=0
  CHECK 4: Upscaling score formula -- PieAPP → sigmoid → log transform → final score
  CHECK 5: Compression score formula -- exact replica of scoring_function.py
  CHECK 6: Length score formula -- log(1 + content_length) / log(1 + 320)
  CHECK 7: Upscaling final score -- S_pre = 0.5*S_Q + 0.5*S_L → S_F = 0.1*e^(6.979*(S_pre-0.5))
  CHECK 8: EWMA accumulation -- decay_factor=0.75 rolling average
  CHECK 9: Weight tier structure -- compression 30%+30% / upscaling 20%+20%, cutoff rank 50
  CHECK 10: Penalty/bonus thresholds -- bonus at S_F>0.32, penalty at S_F<0.20 (upscaling)
  CHECK 11: Video output validity -- response URL returns valid video, frame count matches

WHAT REQUIRES THE VALIDATOR STACK (not tested here):
  - Actual VMAF computation (requires FFmpeg + libvmaf)
  - Actual PieAPP scoring (requires model weights + GPU)
  - Actual compression rate measurement (requires uploaded video sizes)

Repo: https://github.com/vidaio-subnet/vidaio-subnet
"""
from __future__ import annotations
import sys
import os
import math
import hashlib
import importlib.util
import numpy as np

# ── Config values from vidaio_subnet_core/configs/score.py ───────────────────
# Verified against source 2026-03-29
SCORE_CONFIG = {
    "decay_factor": 0.75,
    "vmaf_threshold": 0.5,        # normalised -- VMAF score / 100 must be > 0.5
    "vmaf_sample_count": 10,
    "pieapp_threshold": 1.0,
    "pieapp_sample_count": 4,
    "max_performance_records": 10,
    "synthetics_hours_threshold": 5,
    "synthetics_select_probability": 0.7,
}

# From miner_manager.py lines 63-90
WEIGHT_CONFIG = {
    "burn_proportion": 4/5,            # 80% burnt to subnet owner
    "top_n_compression_cutoff": 50,    # ranks 1-50 earn, rest get 0
    "top_n_upscaling_cutoff": 50,
    "alloc_comp_top": 0.30,           # top-10 compression: 30% of total emissions
    "alloc_comp_mid": 0.30,           # rank 11-50 compression: 30%
    "alloc_up_top": 0.20,             # top-10 upscaling: 20%
    "alloc_up_mid": 0.20,             # rank 11-50 upscaling: 20%
    "top_n_tier_boundary": 10,
}

# From miner_manager.py lines 63-90
UPSCALING_CONFIG = {
    "bonus_threshold": 0.32,          # S_F > 0.32 triggers bonus
    "penalty_f_threshold": 0.07,      # miner_manager PENALTY_F_THRESHOLD (note: doc says 0.20)
    "penalty_q_threshold": 0.5,       # S_Q < 0.5
    "bonus_max": 0.15,                # +15%
    "penalty_f_max": 0.20,            # -20%
    "penalty_q_max": 0.25,            # -25%
    "quality_weight": 0.5,            # W1
    "length_weight": 0.5,             # W2
}

COMPRESSION_CONFIG = {
    "bonus_threshold": 0.74,
    "penalty_f_threshold": 0.4,
    "vmaf_margin": 0.0,
    "bonus_max": 0.15,
    "penalty_f_max": 0.20,
    "penalty_vmaf_max": 0.30,
    "compression_weight": 0.70,       # w_c in scoring_function.py
    "quality_weight": 0.30,           # w_q
    "normalization_factor": 1.12,
    "soft_threshold_margin": 5.0,
    "no_compression_threshold": 0.80, # rate >= 0.80 → score=0
}

VIDAIO_REPO_PATH = os.environ.get(
    "VIDAIO_REPO_PATH",
    os.path.join(os.path.dirname(__file__), "..", "..", "vidaio-subnet")
)


# ── CHECK 4: PieAPP scoring (upscaling) ──────────────────────────────────────
def sigmoid(x: float) -> float:
    """Exact replica of sigmoid() in video_similarity_score_sythetic.py"""
    return 1 / (1 + math.exp(-x))


def calculate_final_score_upscaling(pieapp_score: float) -> float:
    """
    Exact replica of calculate_final_score() in video_similarity_score_sythetic.py.
    Transforms PieAPP score (lower = better) to final score (higher = better, 0-1 range).
    """
    sigmoid_normalized_score = sigmoid(pieapp_score)
    original_at_zero = (1 - (math.log10(sigmoid(0) + 1) / math.log10(3.5))) ** 2.5
    original_at_two  = (1 - (math.log10(sigmoid(2.0) + 1) / math.log10(3.5))) ** 2.5
    original_value   = (1 - (math.log10(sigmoid_normalized_score + 1) / math.log10(3.5))) ** 2.5
    scaled_value     = 1 - ((original_value - original_at_zero) / (original_at_two - original_at_zero))
    return scaled_value


# ── CHECK 5: Compression scoring ─────────────────────────────────────────────
def calculate_compression_score(
    vmaf_score: float,
    compression_rate: float,
    vmaf_threshold: float,
    compression_weight: float = 0.70,
    quality_weight: float = 0.30,
    soft_threshold_margin: float = 5.0,
    normalization_factor: float = 1.12,
) -> tuple[float, float, float, str]:
    """
    Exact replica of calculate_compression_score() in scoring_function.py.
    vmaf_score: 0-100
    compression_rate: compressed_size / original_size (0-1, lower = better)
    vmaf_threshold: e.g. 85, 89, 93 (0-100 scale)
    Returns (final_score, compression_component, quality_component, reason)
    """
    if abs(compression_weight + quality_weight - 1.0) > 0.01:
        raise ValueError("Weights must sum to 1.0")

    hard_cutoff = vmaf_threshold - soft_threshold_margin

    # Case 0: no meaningful compression
    if compression_rate >= 0.80:
        ratio = 1 / compression_rate if compression_rate > 0 else 1.0
        return 0.0, 0.0, 0.0, f"No meaningful compression (ratio: {ratio:.2f}x, rate: {compression_rate:.2f})"

    # Case 1: below hard cutoff
    if vmaf_score < hard_cutoff:
        return 0.0, 0.0, 0.0, f"VMAF {vmaf_score:.2f} below hard cutoff ({hard_cutoff:.2f})"

    compression_ratio = 1 / compression_rate

    # Case 2: soft zone
    if vmaf_score < vmaf_threshold:
        soft_zone_pos = (vmaf_score - hard_cutoff) / soft_threshold_margin
        quality_factor = 0.7 * (soft_zone_pos ** 2)
        if compression_ratio <= 20:
            comp_component = ((compression_ratio - 1) / 19) ** 1.5
        else:
            comp_component = 1.0 + 0.3 * math.log(compression_ratio / 20)
        final = min(1.0, (comp_component * quality_factor) / normalization_factor)
        return final, comp_component, quality_factor, f"VMAF {vmaf_score:.2f} in soft zone"

    # Case 3: above threshold
    vmaf_excess = vmaf_score - vmaf_threshold
    max_vmaf_excess = 100 - vmaf_threshold
    quality_component = 0.7 + 0.3 * min(1.0, vmaf_excess / max_vmaf_excess)
    if compression_ratio <= 20:
        comp_component = ((compression_ratio - 1.25) / 18.75) ** 0.9
    else:
        comp_component = 1.0 + 0.1 * math.log(compression_ratio / 20)
    final = min(1.0, (compression_weight * comp_component + quality_weight * quality_component) / normalization_factor)
    return final, comp_component, quality_component, "success"


# ── CHECK 6: Length score ─────────────────────────────────────────────────────
def calculate_length_score(content_length_seconds: float) -> float:
    """
    Exact replica of length score formula from incentive_mechanism.md.
    S_L = log(1 + content_length) / log(1 + 320)
    """
    return math.log(1 + content_length_seconds) / math.log(1 + 320)


# ── CHECK 7: Upscaling final score ────────────────────────────────────────────
def calculate_upscaling_final_score(s_q: float, s_l: float) -> float:
    """
    Exact replica of upscaling final score formula from incentive_mechanism.md.
    S_pre = S_Q * W1 + S_L * W2 (W1=W2=0.5)
    S_F = 0.1 * e^(6.979 * (S_pre - 0.5))
    """
    w1 = UPSCALING_CONFIG["quality_weight"]
    w2 = UPSCALING_CONFIG["length_weight"]
    s_pre = s_q * w1 + s_l * w2
    s_f = 0.1 * math.exp(6.979 * (s_pre - 0.5))
    return s_pre, s_f


# ── CHECK 8: EWMA accumulation ────────────────────────────────────────────────
def accumulate_score(current_ewma: float, new_score: float, decay: float = 0.75) -> float:
    """
    Exact replica of score accumulation from miner_manager.py lines 339-340.
    new_ewma = current * decay_factor + new_score * (1 - decay_factor)
    """
    return current_ewma * decay + new_score * (1 - decay)


# ═══════════════════════════════════════════════════════════════════════════════
# TESTS
# ═══════════════════════════════════════════════════════════════════════════════

def test_vmaf_gate_upscaling():
    """
    CHECK 3a: VMAF gate for upscaling.
    vmaf_threshold = 0.5 (normalised). VMAF score / 100 < 0.5 → score = 0.
    From video_similarity_score_sythetic.py line 360: if vmaf_score / 100 < VMAF_THRESHOLD
    """
    gate = SCORE_CONFIG["vmaf_threshold"]  # 0.5

    # At VMAF=49 (raw) = 0.49 normalised → fails gate
    vmaf_raw_fail = 49
    assert vmaf_raw_fail / 100 < gate, (
        f"VMAF={vmaf_raw_fail} should fail gate (normalised={vmaf_raw_fail/100:.2f} < {gate})"
    )

    # At VMAF=51 (raw) → passes gate
    vmaf_raw_pass = 51
    assert vmaf_raw_pass / 100 >= gate, (
        f"VMAF={vmaf_raw_pass} should pass gate (normalised={vmaf_raw_pass/100:.2f} >= {gate})"
    )

    print(f"  VMAF gate: {gate*100:.0f}/100 (raw). VMAF < {gate*100:.0f} → score = 0.")
    print(f"  Note: gate is LOW (50/100). Real competition is in VMAF 85-95+ range.")


def test_vmaf_gate_compression():
    """
    CHECK 3b: VMAF gate for compression.
    vmaf_threshold passed in by validator per-task (e.g. 85, 89, 93).
    Hard cutoff = vmaf_threshold - 5. Below hard cutoff → score = 0.
    """
    for threshold in [85, 89, 93]:
        hard_cutoff = threshold - COMPRESSION_CONFIG["soft_threshold_margin"]

        # Below hard cutoff
        score, _, _, reason = calculate_compression_score(
            vmaf_score=hard_cutoff - 1,
            compression_rate=0.20,
            vmaf_threshold=threshold,
        )
        assert score == 0.0, f"threshold={threshold}: VMAF below hard cutoff should give 0, got {score}"

        # At threshold
        score_at, _, _, _ = calculate_compression_score(
            vmaf_score=threshold,
            compression_rate=0.10,
            vmaf_threshold=threshold,
        )
        assert score_at > 0, f"threshold={threshold}: VMAF at threshold with good compression should give >0"

    print(f"  Compression VMAF hard cutoffs: 80, 84, 88 (for thresholds 85, 89, 93)")
    print(f"  Below hard cutoff → score=0 regardless of compression ratio.")


def test_pieapp_score_formula():
    """
    CHECK 4: PieAPP sigmoid-log transform.
    Lower PieAPP = better. Transform to higher = better in [0,1].
    """
    # Score at 0 (perfect) should be high
    score_perfect = calculate_final_score_upscaling(0.0)
    # Score at 2.0 (poor) should be ~0
    score_poor = calculate_final_score_upscaling(2.0)
    # Score at 1.0 (average) should be between
    score_avg = calculate_final_score_upscaling(1.0)

    assert score_perfect > score_avg > score_poor, (
        f"PieAPP transform should be monotonically decreasing with PieAPP score. "
        f"Got: perfect={score_perfect:.4f}, avg={score_avg:.4f}, poor={score_poor:.4f}"
    )
    assert 0.0 <= score_poor <= 1.0
    assert 0.0 <= score_perfect <= 1.0

    print(f"  PieAPP=0.0 (perfect) → final_score={score_perfect:.4f}")
    print(f"  PieAPP=1.0 (average) → final_score={score_avg:.4f}")
    print(f"  PieAPP=2.0 (poor)    → final_score={score_poor:.4f}")
    print(f"  Formula: sigmoid → log10_norm → power 2.5 → rescale [0,2] to [0,1]")


def test_compression_formula_cases():
    """
    CHECK 5: Compression scoring formula -- all three zones.
    """
    vmaf_threshold = 85.0

    # Case 0: no meaningful compression (rate >= 0.80)
    score, _, _, reason = calculate_compression_score(95.0, 0.85, vmaf_threshold)
    assert score == 0.0, f"rate=0.85 (1.18x) should give 0 (too little compression)"
    assert "No meaningful compression" in reason

    # Case 1: below hard cutoff (VMAF < 80)
    score, _, _, reason = calculate_compression_score(79.0, 0.10, vmaf_threshold)
    assert score == 0.0, f"VMAF=79 (below hard cutoff=80) should give 0"

    # Case 2: soft zone (VMAF 80-85)
    score, _, _, reason = calculate_compression_score(83.0, 0.10, vmaf_threshold)
    assert 0.0 < score < 0.5, f"Soft zone should give partial score, got {score:.4f}"

    # Case 3: above threshold -- good compression
    score_good, _, _, _ = calculate_compression_score(90.0, 0.10, vmaf_threshold)  # 10x
    score_great, _, _, _ = calculate_compression_score(90.0, 0.05, vmaf_threshold) # 20x
    assert score_great > score_good, "Better compression should give higher score"

    # Verify 15x compression at threshold VMAF
    score_15x, comp_c, qual_c, reason = calculate_compression_score(85.0, 1/15, vmaf_threshold)
    print(f"  15x compression at VMAF=85 (threshold): score={score_15x:.4f}")
    print(f"  20x compression at VMAF=90: score={score_great:.4f}")
    print(f"  Compression weight=0.70, quality weight=0.30, normalization=1.12")


def test_length_score():
    """
    CHECK 6: Length score formula S_L = log(1+t) / log(321).
    Currently only 5s and 10s are supported (MAX_CONTENT_LEN = ContentLength.FIVE = 5).
    """
    cases = [(5, 0.3105), (10, 0.4155), (20, 0.5275), (40, 0.6434), (320, 1.0)]
    for seconds, expected in cases:
        score = calculate_length_score(seconds)
        assert abs(score - expected) < 0.001, (
            f"S_L({seconds}s) = {score:.4f}, expected {expected:.4f}"
        )

    s5  = calculate_length_score(5)
    s10 = calculate_length_score(10)
    print(f"  S_L(5s)  = {s5:.4f} (31.05%) -- DEFAULT -- only duration available by default")
    print(f"  S_L(10s) = {s10:.4f} (41.55%) -- available -- +33% gain vs 5s")
    print(f"  CRITICAL: miner.py MAX_CONTENT_LEN=ContentLength.FIVE by default.")
    print(f"  Change to ContentLength.TEN to claim +33% length score gain.")


def test_upscaling_final_score():
    """
    CHECK 7: Upscaling final score S_F = 0.1 * e^(6.979 * (S_pre - 0.5)).
    This exponential transform creates massive performance differentiation.
    """
    cases = [
        # (s_q, s_l, expected_s_pre, min_s_f, max_s_f)
        (0.0, calculate_length_score(5), None, 0.0, 0.05),    # zero quality
        (0.5, calculate_length_score(5), None, 0.05, 0.12),   # mediocre
        (0.8, calculate_length_score(5), None, 0.12, 0.40),   # decent
        (0.9, calculate_length_score(10), None, 0.30, 1.0),   # good quality + 10s
    ]
    for s_q, s_l, _, min_sf, max_sf in cases:
        s_pre, s_f = calculate_upscaling_final_score(s_q, s_l)
        assert min_sf <= s_f <= max_sf, (
            f"S_Q={s_q:.2f}, S_L={s_l:.4f}: S_F={s_f:.4f} not in [{min_sf}, {max_sf}]"
        )

    # Verify the exponential amplification
    _, sf_low  = calculate_upscaling_final_score(0.4, calculate_length_score(5))
    _, sf_high = calculate_upscaling_final_score(0.9, calculate_length_score(10))
    ratio = sf_high / max(sf_low, 1e-6)
    print(f"  Poor miner (S_Q=0.4, 5s):  S_F={sf_low:.4f}")
    print(f"  Good miner (S_Q=0.9, 10s): S_F={sf_high:.4f}")
    print(f"  Ratio: {ratio:.1f}x -- exponential formula strongly separates tiers")
    print(f"  MINIMUM TARGET: S_pre > 0.6 for meaningful reward activation")


def test_ewma_accumulation():
    """
    CHECK 8: EWMA accumulation with decay_factor=0.75.
    new = old * 0.75 + new_score * 0.25
    10 rounds to reach ~94% of a new steady-state score.
    """
    decay = SCORE_CONFIG["decay_factor"]
    assert abs(decay - 0.75) < 1e-9, f"Expected decay_factor=0.75, got {decay}"

    # Simulate a miner going from 0 to a new consistent score of 0.5
    ewma = 0.0
    for _ in range(10):
        ewma = accumulate_score(ewma, 0.5, decay)
    # After 10 rounds: 0.5 * (1 - 0.75^10) = 0.5 * 0.944 = 0.472
    expected_10 = 0.5 * (1 - 0.75**10)
    assert abs(ewma - expected_10) < 1e-6, f"EWMA after 10 rounds: {ewma:.4f} vs expected {expected_10:.4f}"

    # Recovery time: rounds to recover from a 0.0 drop
    ewma_drop = 0.5
    n_recovery = 0
    while ewma_drop > 0.1:
        ewma_drop = accumulate_score(ewma_drop, 0.0, decay)
        n_recovery += 1
    print(f"  EWMA decay_factor=0.75 (α=0.25)")
    print(f"  After 10 rounds of new score: {ewma:.4f} (target=0.5)")
    print(f"  Rounds to drop to 10% of current: {n_recovery}")
    print(f"  One bad round at 0.0 contaminates score for ~{n_recovery} rounds")


def test_weight_tier_structure():
    """
    CHECK 9: Weight tier structure.
    Compression: top-10 → 30%, rank 11-50 → 30%. Rank >50 → 0.
    Upscaling:   top-10 → 20%, rank 11-50 → 20%. Rank >50 → 0.
    burn_proportion = 4/5 (80% of miner emissions burnt to subnet owner).
    """
    # Verify allocations sum correctly
    alloc_total = (WEIGHT_CONFIG["alloc_comp_top"] + WEIGHT_CONFIG["alloc_comp_mid"] +
                   WEIGHT_CONFIG["alloc_up_top"] + WEIGHT_CONFIG["alloc_up_mid"])
    assert abs(alloc_total - 1.0) < 1e-9, (
        f"Allocations should sum to 1.0, got {alloc_total}"
    )

    burn = WEIGHT_CONFIG["burn_proportion"]
    assert abs(burn - 4/5) < 1e-9, f"burn_proportion should be 0.8 (4/5), got {burn}"

    print(f"  Compression top-10:  {WEIGHT_CONFIG['alloc_comp_top']*100:.0f}% of total")
    print(f"  Compression rank 11-50: {WEIGHT_CONFIG['alloc_comp_mid']*100:.0f}% of total")
    print(f"  Upscaling top-10:    {WEIGHT_CONFIG['alloc_up_top']*100:.0f}% of total")
    print(f"  Upscaling rank 11-50:   {WEIGHT_CONFIG['alloc_up_mid']*100:.0f}% of total")
    print(f"  Burn proportion: {burn*100:.0f}% (to subnet owner)")
    print(f"  Effective miner earnings: {(1-burn)*100:.0f}% of total emissions")
    print(f"  Hard cutoff: rank > 50 earns ZERO regardless of score")


def test_upscaling_penalty_bonus_thresholds():
    """
    CHECK 10a: Upscaling penalty/bonus thresholds.
    Bonus activated when S_F > 0.32 in a round (from miner_manager.py).
    Penalty activated when S_F < 0.07 (PENALTY_F_THRESHOLD from source).
    """
    # Verify bonus threshold corresponds to a meaningful S_pre level
    bonus_sf = UPSCALING_CONFIG["bonus_threshold"]  # 0.32

    # Reverse-engineer the S_pre that gives S_F = 0.32
    # 0.32 = 0.1 * e^(6.979 * (S_pre - 0.5))
    # S_pre = 0.5 + ln(0.32/0.1) / 6.979
    s_pre_for_bonus = 0.5 + math.log(bonus_sf / 0.1) / 6.979
    print(f"  Upscaling bonus threshold: S_F > {bonus_sf} → S_pre > {s_pre_for_bonus:.3f}")
    print(f"  At 5s content: S_Q > {(s_pre_for_bonus - 0.5*calculate_length_score(5))/0.5:.3f} needed for bonus")
    print(f"  At 10s content: S_Q > {(s_pre_for_bonus - 0.5*calculate_length_score(10))/0.5:.3f} needed for bonus")
    print(f"  Bonus system: +1.5% per round above threshold, max +15% (10/10 rounds)")


def test_compression_no_return_exploit():
    """
    CHECK 10b: Compression exploit prevention.
    compression_rate >= 0.80 (less than 1.25x) → score = 0.
    Prevents miners returning the original file to get high VMAF.
    """
    # Return same file (rate = 1.0)
    score, _, _, reason = calculate_compression_score(99.0, 1.0, 85.0)
    assert score == 0.0, "Returning same file should give score=0"

    # Minimal compression (1.1x = rate 0.91)
    score, _, _, reason = calculate_compression_score(99.0, 0.91, 85.0)
    assert score == 0.0, "1.1x compression should give score=0 (< 1.25x minimum)"

    # Just above minimum (1.26x = rate 0.794)
    score, _, _, reason = calculate_compression_score(99.0, 0.794, 85.0)
    assert score >= 0.0, "1.26x compression passes minimum threshold"

    print(f"  Anti-exploit: compression_rate >= 0.80 (< 1.25x) → score = 0")
    print(f"  Minimum meaningful compression: 1.25x (rate=0.80)")
    print(f"  Optimal range: 10-20x compression (rate=0.05-0.10)")


def test_source_code_accessible():
    """
    CHECK 11: Verify vidaio-subnet repo is cloned and scoring_function.py is readable.
    """
    scoring_path = os.path.join(VIDAIO_REPO_PATH, "services", "scoring", "scoring_function.py")
    if not os.path.exists(scoring_path):
        print(f"  SKIP: scoring_function.py not found at {scoring_path}")
        print(f"  Clone repo and set VIDAIO_REPO_PATH env var.")
        print(f"  git clone https://github.com/vidaio-subnet/vidaio-subnet.git")
        return

    # Hash the file to detect changes
    h = hashlib.sha256(open(scoring_path, "rb").read()).hexdigest()[:12]
    hash_file = os.path.join(os.path.dirname(__file__), ".scoring_function_hash")
    if os.path.exists(hash_file):
        stored = open(hash_file).read().strip()
        if stored != h:
            print(f"  WARNING: scoring_function.py has changed! {stored} → {h}")
            print(f"  Review: diff VIDAIO/services/scoring/scoring_function.py against local replica")
    else:
        with open(hash_file, "w") as f:
            f.write(h)
    print(f"  scoring_function.py hash: {h}")

    # Verify our local replica matches the source
    spec = importlib.util.spec_from_file_location("scoring_function", scoring_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    # Cross-check one case
    source_score, _, _, _ = mod.calculate_compression_score(
        vmaf_score=88.0,
        compression_rate=0.10,
        vmaf_threshold=85.0,
    )
    local_score, _, _, _ = calculate_compression_score(88.0, 0.10, 85.0)
    assert abs(source_score - local_score) < 1e-9, (
        f"Local replica diverges from source! source={source_score:.6f}, local={local_score:.6f}"
    )
    print(f"  Local compression formula matches source: {local_score:.6f}")


def test_content_length_declaration():
    """
    CHECK: miner.py declares MAX_CONTENT_LEN = ContentLength.FIVE by default.
    Changing to ContentLength.TEN gives +33% length score boost with no quality change.
    This is a Tier 0 (zero-cost) mutation.
    """
    miner_path = os.path.join(VIDAIO_REPO_PATH, "neurons", "miner.py")
    if not os.path.exists(miner_path):
        print(f"  SKIP: miner.py not found at {miner_path}")
        return

    content = open(miner_path).read()
    if "ContentLength.FIVE" in content:
        print(f"  miner.py declares MAX_CONTENT_LEN = ContentLength.FIVE (default)")
        s5  = calculate_length_score(5)
        s10 = calculate_length_score(10)
        gain = (s10 - s5) / s5 * 100
        print(f"  S_L(5s)={s5:.4f} vs S_L(10s)={s10:.4f} = +{gain:.1f}% gain from single line change")
        print(f"  TIER 0 MUTATION: change to ContentLength.TEN if GPU can handle 10s clips")
    elif "ContentLength.TEN" in content:
        print(f"  miner.py already uses ContentLength.TEN -- good")
    else:
        print(f"  Could not detect content length declaration in miner.py")


# ── Main runner ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    tests = [
        ("CHECK 3a", "VMAF gate -- upscaling (threshold=50/100)",
            test_vmaf_gate_upscaling),
        ("CHECK 3b", "VMAF gate -- compression (hard cutoff = threshold - 5)",
            test_vmaf_gate_compression),
        ("CHECK 4",  "PieAPP sigmoid-log score transform (upscaling)",
            test_pieapp_score_formula),
        ("CHECK 5",  "Compression score formula (all 3 zones)",
            test_compression_formula_cases),
        ("CHECK 6",  "Length score S_L = log(1+t) / log(321)",
            test_length_score),
        ("CHECK 7",  "Upscaling final score S_F = 0.1 * e^(6.979 * (S_pre - 0.5))",
            test_upscaling_final_score),
        ("CHECK 8",  "EWMA accumulation decay_factor=0.75",
            test_ewma_accumulation),
        ("CHECK 9",  "Weight tier structure (comp 30+30, up 20+20, cutoff=50)",
            test_weight_tier_structure),
        ("CHECK 10a","Upscaling penalty/bonus thresholds",
            test_upscaling_penalty_bonus_thresholds),
        ("CHECK 10b","Compression anti-exploit (min 1.25x compression)",
            test_compression_no_return_exploit),
        ("CHECK 11", "Source code accessible and local replica matches",
            test_source_code_accessible),
        ("CHECK 12", "Content length declaration in miner.py",
            test_content_length_declaration),
    ]

    passed, failed = 0, 0
    for check_id, desc, fn in tests:
        print(f"\n{check_id}: {desc}")
        try:
            fn()
            print(f"  PASS")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR: {type(e).__name__}: {e}")
            failed += 1

    print(f"\n{'='*65}")
    print(f"{passed} passed, {failed} failed")
    print()
    print("SN85 scoring note:")
    print("  These tests verify the scoring formulas and config thresholds.")
    print("  VMAF and PieAPP scores require the full validator stack (FFmpeg + GPU).")
    print("  Use these tests to understand the scoring surface, not as a substitute")
    print("  for running your model against real validator evaluation.")
    sys.exit(0 if failed == 0 else 1)
