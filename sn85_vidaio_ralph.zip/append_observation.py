#!/usr/bin/env python3
"""
registry/append_observation.py
Called by Claude Code during the fast loop.
Usage: python registry/append_observation.py --round 42 --score 0.187 --rank 31
"""
import argparse, json, hashlib, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

REGISTRY_DIR = Path(__file__).parent
ROOT = REGISTRY_DIR.parent
VIDAIO_DIR = ROOT.parent / "vidaio-subnet"


def get_scoring_hash() -> str | None:
    p = VIDAIO_DIR / "services" / "scoring" / "scoring_function.py"
    if p.exists():
        return hashlib.sha256(p.read_bytes()).hexdigest()[:12]
    return None


def check_scoring_changed() -> bool:
    current = get_scoring_hash()
    if not current:
        return False
    hash_file = ROOT / "scoring_alignment" / ".scoring_function_hash"
    if hash_file.exists():
        stored = hash_file.read_text().strip()
        if stored != current:
            print(f"WARNING: scoring_function.py changed! {stored} -> {current}")
            return True
    else:
        hash_file.parent.mkdir(exist_ok=True)
        hash_file.write_text(current)
    return False


def run_alignment_checks() -> bool:
    test_path = ROOT / "scoring_alignment" / "sn85_vidaio_scoring_alignment.py"
    if not test_path.exists():
        return None  # unknown
    result = subprocess.run(
        [sys.executable, str(test_path)],
        capture_output=True, text=True,
        cwd=str(ROOT),
        env={**__import__("os").environ,
             "VIDAIO_REPO_PATH": str(VIDAIO_DIR)}
    )
    return result.returncode == 0


def count_fast_loops_since_deployment() -> int:
    p = REGISTRY_DIR / "progress.txt"
    if not p.exists():
        return 0
    lines = p.read_text().split("\n")
    last_deploy = -1
    fast_count = 0
    for i, line in enumerate(lines):
        if "DEPLOYING" in line:
            last_deploy = i
            fast_count = 0
        elif "FAST" in line and last_deploy >= 0:
            fast_count += 1
    return fast_count


def get_task_type() -> str:
    p = REGISTRY_DIR / "task_type.txt"
    return p.read_text().strip() if p.exists() else "UNKNOWN"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", type=int, default=0)
    parser.add_argument("--score", type=float, default=None)
    parser.add_argument("--rank", type=int, default=None)
    parser.add_argument("--s-q", type=float, default=None, help="Quality score S_Q (0-1)")
    parser.add_argument("--pieapp", type=float, default=None, help="PieAPP score")
    parser.add_argument("--vmaf", type=float, default=None, help="VMAF score (0-100)")
    args = parser.parse_args()

    task_type = get_task_type()
    scoring_changed = check_scoring_changed()
    checks_ok = run_alignment_checks()
    windows_since_deploy = count_fast_loops_since_deployment()
    ts = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    entry = {
        "round": args.round,
        "timestamp": ts,
        "task_type": task_type,
        "ewma_score": args.score,
        "rank": args.rank,
        "s_q": args.s_q,
        "pieapp": args.pieapp,
        "vmaf": args.vmaf,
        "alignment_checks_pass": checks_ok,
        "scoring_formula_changed": scoring_changed,
        "windows_since_deployment": windows_since_deploy,
    }

    # Append to registry
    with open(REGISTRY_DIR / "agent_registry.jsonl", "a") as f:
        f.write(json.dumps(entry) + "\n")

    # Append to progress.txt
    score_str = f"{args.score:.4f}" if args.score is not None else "unknown"
    rank_str = str(args.rank) if args.rank is not None else "unknown"
    checks_str = "pass" if checks_ok else ("FAIL" if checks_ok is False else "skip")
    formula_str = "CHANGED" if scoring_changed else "ok"
    line = (f"[R{args.round:03d}] FAST -- score={score_str} rank={rank_str} "
            f"task_type={task_type} checks={checks_str} "
            f"formula={formula_str} gate={windows_since_deploy}/5\n")
    with open(REGISTRY_DIR / "progress.txt", "a") as f:
        f.write(line)

    print(line.strip())

    if windows_since_deploy < 5:
        print(f"WINDOW GATE: {windows_since_deploy}/5. Slow loop LOCKED.")
    if scoring_changed:
        print("ACTION REQUIRED: scoring_function.py changed. Review formula updates.")
        sys.exit(2)
    if checks_ok is False:
        print("ACTION REQUIRED: alignment checks FAILED. Fix before next round.")
        sys.exit(3)


if __name__ == "__main__":
    main()
