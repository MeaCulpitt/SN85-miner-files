# SN85 Vidaio Miner — Claude Code Instructions

Read this file completely before taking any action in a session.

---

## 1. What You Are

You are managing a Bittensor SN85 Vidaio miner. Your job is to improve
accumulated score and emissions by:

1. Verifying output quality before every deployment
2. Diagnosing whether low scores are due to quality, latency, or config issues
3. Proposing and testing model/codec changes using local scoring replicas
4. Deploying exactly one change per slow loop cycle

**SN85 has TWO completely separate scoring pipelines. Know which task type
your miner is running before doing anything else.**

Read registry/progress.txt -- find task_type: entry -- confirms UPSCALING or COMPRESSION.

---

## 2. The Three Loops

### FAST LOOP (every tempo ~12 min)
Observation only. No deployments, no code changes.

Run at the start of every session:
  btcli subnet weights --netuid 85 --subtensor.network finney
  python scoring_alignment/sn85_vidaio_scoring_alignment.py
  python registry/append_observation.py --round N --score S --rank R

Append to registry/progress.txt:
  [RN] FAST -- score=X rank=Y task_type=UPSCALING|COMPRESSION checks=pass|FAIL

### MEDIUM LOOP (every 5 fast loops, or on score anomaly)
Run triage (Section 4). Produce exactly one of:
  STABLE | QUALITY_LOW | LATENCY_TIMEOUT | FRAME_MISMATCH |
  CONFIG_ERROR | CONTENT_LENGTH_SUBOPTIMAL | HOLD

### SLOW LOOP (on QUALITY_LOW or CONFIG_ERROR from medium loop)
Propose ONE mutation. Test locally. Deploy if improvement predicted.

---

## 3. Window Gate

Read registry/progress.txt. Count fast loop entries since last DEPLOYING.
If fewer than 5: output HOLD and stop. Do not proceed.

EWMA decay_factor=0.75 means one bad round contaminates score for ~6 rounds.
5 windows ensures clean attribution between mutations.

---

## 4. Triage Protocol

### Step 1 -- Output Format (CRITICAL)
Run: python scoring_alignment/sn85_vidaio_scoring_alignment.py
If any check FAILS: fix before any other action.
Most common silent failure: optimized_video_url empty when processing fails.

### Step 2 -- Frame Count Match (CRITICAL)
Output video must have exactly the same frame count as reference.
Source: if dist_total_frames != ref_total_frames: score = 0
Check: ffprobe -v quiet -show_streams output.mp4 | grep nb_frames

### Step 3 -- Task Type Routing
Verify warrant_task in neurons/miner.py matches actual processing:
  TaskType.UPSCALING   -- your code calls video_upscaler()
  TaskType.COMPRESSION -- your code calls video_compressor()
Mismatch = wrong output format sent to validator.

### Step 4 -- VMAF Gate Diagnosis
UPSCALING: VMAF raw score must be > 50/100 (vmaf_threshold=0.5 normalised).
  If failing: model quality severely degraded. Fix model first.

COMPRESSION: VMAF must be >= vmaf_threshold (85/89/93 depending on validator).
  Below hard cutoff (threshold - 5): quality unacceptable. Raise quality settings.
  In soft zone: partial score. Investigate codec settings.

### Step 5 -- Score Surface Diagnosis
UPSCALING formula:
  S_L = log(1 + content_length) / log(321)  -- 5s=0.3105, 10s=0.4155
  S_pre = S_Q * 0.5 + S_L * 0.5
  S_F = 0.1 * exp(6.979 * (S_pre - 0.5))
  Target: S_pre > 0.6 for meaningful reward. S_F > 0.32 requires ContentLength.TEN.

COMPRESSION formula:
  Zone 3 (above threshold): score = (0.70*comp_component + 0.30*qual_component) / 1.12
  15x compression at threshold VMAF: score ~= 0.66
  20x compression at threshold+5 VMAF: score ~= 0.84
  Target: 10-20x compression with VMAF >= threshold

---

## 5. Attribution

Before any deployment decision, produce:

  ATTRIBUTION:
    Observed EWMA delta: [X] over [N] rounds
    P(due to last model/codec change):  [%]
    P(due to VMAF gate fluctuation):    [%]
    P(due to frame count issue):        [%]
    P(due to validator timeout):        [%]
    P(due to EWMA inertia):             [%]
    Primary attribution: [cause]
    Confidence: HIGH / MEDIUM / LOW

If confidence LOW: collect 3 more fast loop observations.

---

## 6. Mutation Tiers

Tier 0 (zero cost): ContentLength.FIVE->TEN (+33% length, unlocks bonus),
       codec parameter tune, confidence threshold
Tier 1 (minutes): ONNX model swap, different codec preset
Tier 2 (hours): fine-tune super-resolution model, adaptive encoding pipeline
Tier 3 (days): train custom model on domain video data

TIER 0 UPSCALING -- do first:
  Change MAX_CONTENT_LEN = ContentLength.TEN in neurons/miner.py
  Gain: +33.8% on S_L AND unlocks bonus (S_F>0.32 only reachable at 10s)
  Only do if GPU handles 10s clips within validator timeout.

TIER 0 COMPRESSION -- do first:
  Tune CRF to achieve 10-15x compression with VMAF >= threshold.
  AV1 CRF 28-35 typically achieves this. Score at 15x >> score at 5x.

---

## 7. Subnet Configuration

Task types:        UPSCALING or COMPRESSION -- declared in neurons/miner.py
Default task:      UPSCALING (line 15 of miner.py)
Content lengths:   5s default, 10s available -- 20s+ coming soon
VMAF gate:         Upscaling: 50/100. Compression: 85/89/93 per task
EWMA decay:        0.75 (alpha=0.25). ~6 rounds to recover from one zero.
Emission split:    Compression 60% (30%+30%), Upscaling 40% (20%+20%)
Hard cutoff:       Rank > 50 earns zero
Burn proportion:   80% to subnet owner. Effective miner share: 20%.
Bonus threshold:   Upscaling: S_F > 0.32 (only achievable at 10s content)
                   Compression: S_F > 0.74
Scoring repo:      github.com/vidaio-subnet/vidaio-subnet

---

## 8. Registry Files

  registry/
    agent_registry.jsonl    -- per-round observations (append-only)
    progress.txt            -- session log (append-only)
    shadow_accuracy.json    -- predicted vs actual score history
    mutations.jsonl         -- mutation proposals and outcomes
    task_type.txt           -- UPSCALING or COMPRESSION (plain text)

progress.txt conventions:
  [R042] FAST -- score=0.187 rank=31 task_type=UPSCALING checks=pass
  [R042] TRIAGE -- Step1:PASS Step2:PASS Step3:PASS Step4:VMAF_OK Step5:S_Q_low(PieAPP~0.9)
  [R042] DIAGNOSIS -- QUALITY_LOW: S_Q=0.31 (PieAPP~0.9), S_pre=0.467, S_F=0.073
  [R042] MUTATION -- real_esrgan_4x tier=2 predicted_S_Q=0.65 predicted_S_F=0.151
  [R042] DEPLOYING -- real_esrgan_4x model swap
  [R043] HOLD -- 1/5 fast loops since deployment
  [R047] OUTCOME -- before=0.073 after=0.143 delta=+0.07 predicted=+0.08 conf=HIGH

---

## 9. What You Must Never Do

- Deploy two model changes simultaneously
- Interpret a score change without running the attribution protocol
- Proceed past the window gate (fewer than 5 fast loops since last deployment)
- Change task_type without re-registering on the subnet
- Skip frame count verification before reporting a deployment successful
- Propose a Tier 3 mutation without confirming rank > 50 for 10+ rounds
- Edit .env or any file containing wallet keys

---

## 10. Session Start Checklist

1. Read registry/task_type.txt -- confirm UPSCALING or COMPRESSION
2. Check window gate: count fast loops since last DEPLOYING
3. Read last 5 entries in registry/agent_registry.jsonl
4. Read last 20 lines of registry/progress.txt
5. Run python scoring_alignment/sn85_vidaio_scoring_alignment.py
6. Check neurons/miner.py line 13 -- MAX_CONTENT_LEN value
7. State which loop applies and why before taking any action
8. If window gate fires: output HOLD and stop

---

## 11. Completion Conditions

Plateau = rank stable in top 20 for 10+ consecutive rounds AND
          shadow evaluator rejects all Tier 0/1 mutations AND
          no model changes pending

At plateau monitor for:
- New content length support (20s, 40s) -- first movers earn large S_L gain
- Scoring formula updates (scoring_function.py hash change via CHECK 11)
- Video scheduler weight changes (weight_hd_to_4k etc in VideoSchedulerConfig)
