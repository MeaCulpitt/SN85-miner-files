# SN123 MANTIS Miner Iteration Plan
# Read by Claude Code at the start of each session alongside progress.txt.
# Updated manually when strategy changes. Do not update during a session.

## CURRENT ELEMENT
Subnet: 123 (MANTIS)
Challenges: 10 active (see subnet_config.json for full list)
Highest weight: MULTI-BREAKOUT (5.0), ETH-LBFGS (3.5), XSEC-RANK (3.0)

## SCOPE CONSTRAINT
Only work on the active challenges in config.py.
Never modify MANTIS repo source files (config.py, model.py, ledger.py etc).
Your miner code is generator.py. The validator source is read-only reference.

## THE FUNDAMENTAL OBJECTIVE
You are scored on MARGINAL CONTRIBUTION to a shared ensemble.
Above the noise floor (~53-55% accuracy):
  Improving accuracy in the same direction as existing miners = LOWER salience
  Producing uncorrelated signals = HIGHER salience
The iteration strategy INVERTS at the noise floor.

## ALIGNMENT CHECKS (run before every submission)
File: scoring_alignment/sn123_mantis_tests.py

| Check | Priority | What it catches |
|-------|----------|-----------------|
| 1a    | CRITICAL | V2 payload missing required fields |
| 1b    | CRITICAL | Payload > 25 MB |
| 1c    | CRITICAL | Wrong commit URL format (not *.r2.dev/{hotkey}) |
| 2a    | CRITICAL | Wrong embedding dimensions vs config.CHALLENGES |
| 2b    | CRITICAL | Values outside [-1, 1] -- information loss from clipping |
| 2c    | CRITICAL | All-zero embeddings -- stored but earn zero salience |
| 3     | HIGH     | LBFGS structure (dim=17 challenges) |
| 4     | HIGH     | Hotkey mismatch in payload -- delayed rejection 300 blocks |
| 5     | HIGH     | Timelock round < 3600s -- security model weakened |
| 6     | MEDIUM   | Local salience via evaluate_embeddings.py |
| 7     | MEDIUM   | config.py changed since last session |

## TRIAGE PROTOCOL (ordered -- stop at first failure)
1. Commit URL reachable (curl -sI $URL | grep HTTP)
2. Embedding validity (run alignment checks 2a, 2b, 2c)
3. Cold start check (T >= 500 samples in DataLog)
4. Config change (CHECK 7)
5. DataLog freshness (< 7 days)
6. Salience diagnosis:
   evaluate_embeddings rank vs raw AUC
   rank > 30 AND auc > 55% → ENSEMBLE_SATURATED → diversify
   rank > 30 AND auc < 55% → QUALITY_GAP → improve accuracy
   rank <= 30 → STABLE → monitor
   not in output → COLD_START → wait

## MUTATION TIERS
Tier 0 (zero cost, immediate): embedding scaling, value range adjustment,
        random seed change -- no resubmission needed
Tier 1 (low cost, resubmit): new feature set, different technical indicator,
        different normalisation -- resubmit same generator structure
Tier 2 (hours, rewrite): new model architecture, different prediction horizon,
        new asset focus, LBFGS Q structure improvement -- full generator rewrite
Tier 3 (days, rebuild): new asset class coverage (e.g. add all 33 BREAKOUT_ASSETS),
        new loss function type, fundamental strategy shift

## CHALLENGE PRIORITY FOR ITERATION
1. MULTI-BREAKOUT (weight=5.0): highest leverage, multi-asset dict format
2. ETH-LBFGS (weight=3.5): LBFGS structure matters, higher quality floor needed
3. XSEC-RANK (weight=3.0): cross-sectional signals, naturally low correlation
4. BTC-LBFGS-6H (weight=2.875): similar to ETH-LBFGS, 6h horizon
5. ETH-HITFIRST-100M (weight=2.5): level-touch prediction
6-10. Binary forex/metals (weight=1.0 each): lower saturation, good diversification

## DIVERSIFICATION STRATEGIES (ordered by expected salience gain)
1. Improve MULTI-BREAKOUT quality -- most miners use simple directional signals here
2. Improve XSEC-RANK via relative value signals -- structurally uncorrelated
3. Exploit forex/metals (CADUSD, NZDUSD, CHFUSD, XAGUSD) -- lower saturation than ETH/BTC
4. Improve LBFGS Q matrix structure -- most miners submit poor Q, using p only
5. Different prediction horizon on existing assets
6. Different feature engineering (order flow vs price vs volatility)

## ITERATION ORDER (by phase)
Phase 1 (payload validation): no model changes, just verify delivery
Phase 2 (cold start): wait for T>=500, record baseline rank
Phase 3 (noise floor): measure directional accuracy, compare to 53-55% threshold
Phase 4 (diversification): use evaluate_embeddings.py to diagnose and fix
Phase 5 (monitoring): watch for new correlated miners, config changes

## COMPLETION CONDITION
Plateau = rank stable in top 20 for 10+ consecutive fast-loop cycles
         AND all Tier 0/1 mutations rejected by evaluate_embeddings.py
         AND no config.py changes in last 30 cycles
At plateau: enter monitoring mode (fast loop only)

## KNOWN SILENT FAILURES (check first on any unexplained weight drop)
1. Commit URL 404 -- validator downloads nothing
2. All-zero embeddings -- stored but produce zero salience
3. Wrong dimensions -- silently skipped by evaluate_embeddings.inject_synthetic_embeddings
4. Hotkey mismatch -- rejected 300 blocks after submission
5. DataLog reset -- your local rank estimates are stale
6. config.py change -- your dimensions are now wrong for some challenges
7. Multi-asset format wrong -- returned list instead of dict for MULTI-BREAKOUT/XSEC-RANK
