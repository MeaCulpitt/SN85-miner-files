# SN123 MANTIS — Claude Code Ralph Loop

A complete Claude Code agent framework for iterative self-improvement on
Bittensor Subnet 123 (MANTIS). Drop into your miner repository and start
Claude Code.

## What's Included

```
sn123_ralph/
├── CLAUDE.md                          ← Claude Code reads this first (the loop)
├── subnet_config.json                 ← All config.py values + scoring parameters
├── plan.md                            ← Iteration strategy (Claude Code reads per session)
├── generator.py                       ← Your embedding generator template
├── registry/
│   ├── init_registry.py               ← Run once to initialise
│   ├── append_observation.py          ← Called by Claude Code each fast loop
│   ├── progress.txt                   ← Append-only session log
│   ├── shadow_accuracy.json           ← evaluate_embeddings.py rank history
│   ├── buffer_metadata.json           ← DataLog download state
│   └── last_commit_url.txt            ← Your R2 commit URL
└── scoring_alignment/
    └── sn123_mantis_tests.py          ← 11 alignment checks
```

## Setup

**1. Clone the MANTIS repo alongside this directory:**
```bash
git clone https://github.com/Barbariandev/MANTIS.git ../MANTIS
```

**2. Initialise the registry:**
```bash
python registry/init_registry.py --hotkey YOUR_HOTKEY_SS58
```

**3. Run alignment checks:**
```bash
export MANTIS_REPO_PATH=../MANTIS
python scoring_alignment/sn123_mantis_tests.py
```
All 11 checks must pass before first submission.

**4. Implement your generator:**

Edit `generator.py`. Replace the placeholder `_predict_*` functions with
your actual prediction models. The contract is fixed:
```python
def generate_embeddings(block: int) -> list:
    # Returns exactly 10 embeddings in config.CHALLENGES order
    # See generator.py for full specification
```

Validate before every submission:
```bash
python generator.py
```

**5. Update your commit URL:**
```bash
echo "https://YOUR-BUCKET.r2.dev/YOUR-HOTKEY" > registry/last_commit_url.txt
```

**6. Start Claude Code:**
```bash
claude
```

Claude Code reads `CLAUDE.md` automatically and runs the session start
checklist. Your first prompt:

> "Read CLAUDE.md and subnet_config.json, then run the session start
> checklist from Section 11."

---

## How the Loop Works

Claude Code **is** the loop. There is no shell script. `CLAUDE.md` defines
the behaviour; `progress.txt` is the state; `subnet_config.json` is the
parameters. Claude Code runs the appropriate loop on each session:

**Fast loop** (every ~72 min / 360 blocks):
Observe weight, check URL, detect config changes, append to registry.
No model changes.

**Medium loop** (every 5+ fast loop cycles):
Run triage. Diagnose: STABLE / QUALITY_GAP / ENSEMBLE_SATURATED /
PAYLOAD_FAILURE / CONFIG_CHANGED / COLD_START / HOLD.

**Slow loop** (when medium loop produces QUALITY_GAP or ENSEMBLE_SATURATED):
Propose one mutation. Validate with evaluate_embeddings.py. Deploy if
predicted rank improvement > 3 positions.

**Window gate:** Claude Code refuses to deploy if fewer than 10 fast loop
cycles have passed since the last deployment (~30 hours). The 300-block
decryption delay means the minimum observable feedback cycle is ~132 minutes;
10 cycles ensures clean attribution.

---

## The Fundamental Strategy Difference vs SN44

SN44: higher accuracy → higher score (direct, absolute scoring).

MANTIS: higher accuracy in the same direction as existing miners → **lower**
salience (cooperative, marginal contribution scoring).

Above the noise floor (~53-55% directional accuracy):
- `evaluate_embeddings.py rank << raw AUC` → **ENSEMBLE_SATURATED** → diversify
- `evaluate_embeddings.py rank ≈ raw AUC, both low` → **QUALITY_GAP** → improve accuracy

These require opposite responses. Getting this diagnosis right is the most
important thing the medium loop does.

---

## Challenge Priority

| Challenge | Weight | Notes |
|---|---|---|
| MULTI-BREAKOUT | 5.0 | Highest weight. Dict format: {asset: [float, float]} for 33 assets |
| ETH-LBFGS | 3.5 | LBFGS 17-dim. p (direction) + Q (16-element matrix) |
| XSEC-RANK | 3.0 | Cross-sectional ranking. Dict format. Naturally low correlation. |
| BTC-LBFGS-6H | 2.875 | Same structure as ETH-LBFGS, 6h horizon |
| ETH-HITFIRST-100M | 2.5 | 3-dim level-touch prediction |
| CADUSD/NZDUSD/CHFUSD/XAGUSD (x4) | 1.0 each | Forex/metals. Lower saturation than crypto. |

---

## Silent Failures (check first on any unexplained weight drop)

1. **Commit URL 404** — validator downloads nothing. `curl -sI your-url`
2. **All-zero embeddings** — stored, earn exactly zero salience
3. **Wrong dimensions** — silently skipped by `inject_synthetic_embeddings()`
4. **Hotkey mismatch** — rejected 300 blocks after submission (delayed)
5. **Multi-asset format wrong** — MULTI-BREAKOUT/XSEC-RANK need dict not list
6. **`TLOCK_DEFAULT_LOCK_SECONDS=30`** — dev default, 30s timelock in production
   means Drand has already published the signature. Always set:
   `export TLOCK_PROD_SUGGESTED_LOCK_SECONDS=3600`
7. **DataLog reset** — local rank estimates stale. Download fresh DataLog.
8. **config.py change** — new challenge dims. Run CHECK 7 after every git pull.

---

## Key Numbers (from config.py, verified 2026-03-29)

| Parameter | Value | Meaning |
|---|---|---|
| Decryption delay | 300 blocks (~60 min) | All failures revealed here |
| T minimum | 500 samples | Below this: invisible to salience function |
| TOP_K | 20 | Pre-selection pool for meta-model |
| Effective earning rank | ~20-30 of 256 | Below this: near-zero emissions |
| Noise floor | ~53-55% accuracy | Below this: embeddings treated as noise |
| l1_ratio | 0.5 (elastic-net) | Meta-model sparsifies: 2 correlated miners split 1 miner's salience |
| WINDOWS_HALF_LIFE | 10 | Recency weight half-life |
| MAX_DAYS | 60 | Training history window |
| BURN_PCT | 0.30 | 30% of weights reserved for young UIDs |
| TLOCK_PROD | 3600s | Use this. TLOCK_DEFAULT=30s is dev only. |

---

## Local Salience Evaluation

The most important tool for MANTIS iteration:

```bash
export MANTIS_REPO_PATH=../MANTIS
export MANTIS_GENERATOR_PATH=./generator.py
cd ../MANTIS
python evaluate_embeddings.py --generator $MANTIS_GENERATOR_PATH --days 7
```

Output:
```
synthetic_hotkey salience: 0.004123 | rank 22 / 247
```

Run this after every model change before submitting. A fresh DataLog
(< 7 days) is required for accurate results.
