#!/usr/bin/env python3
"""
registry/append_observation.py

Called by Claude Code during the fast loop to append a structured
observation to agent_registry.jsonl.

Reads:
  - on-chain weight for your UID (if btcli available)
  - last_commit_url.txt reachability
  - config.py hash (CHECK 7 equivalent)
  - buffer_metadata.json DataLog age
  - shadow_accuracy.json last evaluate rank

Usage:
    python registry/append_observation.py
    python registry/append_observation.py --round 42 --weight 0.0031 --rank 24
"""
import argparse
import json
import os
import hashlib
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

REGISTRY_DIR = Path(__file__).parent
ROOT = REGISTRY_DIR.parent
MANTIS_DIR = ROOT.parent / "MANTIS"


def get_config_hash() -> str | None:
    config_path = MANTIS_DIR / "config.py"
    if config_path.exists():
        return hashlib.sha256(config_path.read_bytes()).hexdigest()[:12]
    return None


def check_url(url: str) -> tuple[bool, int]:
    if not HAS_REQUESTS or not url or "YOUR" in url:
        return False, 0
    try:
        r = requests.head(url, timeout=10)
        return r.status_code == 200, r.status_code
    except Exception:
        return False, 0


def read_last_rank() -> tuple[float | None, float | None]:
    """Read last evaluate_embeddings.py rank from shadow_accuracy.json."""
    shadow_path = REGISTRY_DIR / "shadow_accuracy.json"
    if not shadow_path.exists():
        return None, None
    try:
        data = json.loads(shadow_path.read_text())
        return data.get("last_rank"), data.get("last_salience")
    except Exception:
        return None, None


def read_datalog_age() -> float | None:
    path = REGISTRY_DIR / "buffer_metadata.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        ts = data.get("last_download_timestamp")
        if not ts:
            return None
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        return (now - dt).total_seconds() / 86400
    except Exception:
        return None


def count_fast_loops_since_deployment() -> int:
    progress_path = REGISTRY_DIR / "progress.txt"
    if not progress_path.exists():
        return 0
    lines = progress_path.read_text().split("\n")
    last_deploy_idx = -1
    fast_loops = 0
    for i, line in enumerate(lines):
        if "DEPLOYING" in line or ("SLOW" in line and "deploying=true" in line):
            last_deploy_idx = i
            fast_loops = 0
        elif "FAST" in line and last_deploy_idx >= 0:
            fast_loops += 1
    return fast_loops


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", type=int, default=0)
    parser.add_argument("--weight", type=float, default=None)
    parser.add_argument("--rank", type=int, default=None)
    parser.add_argument("--block", type=int, default=None)
    parser.add_argument("--auc", type=float, default=None,
                        help="Your estimated directional accuracy (0-1)")
    args = parser.parse_args()

    # Read commit URL
    url_file = REGISTRY_DIR / "last_commit_url.txt"
    commit_url = url_file.read_text().strip() if url_file.exists() else ""

    url_ok, url_code = check_url(commit_url)
    config_hash = get_config_hash()
    eval_rank, eval_salience = read_last_rank()
    datalog_age = read_datalog_age()
    windows_since_deploy = count_fast_loops_since_deployment()

    # Read stored config hash to detect changes
    hash_file = ROOT / "scoring_alignment" / ".config_hash"
    config_changed = False
    if hash_file.exists() and config_hash:
        stored = hash_file.read_text().strip()
        if stored != config_hash:
            config_changed = True
            print(f"WARNING: config.py has changed! {stored} -> {config_hash}")
            print("Run: python scoring_alignment/sn123_mantis_tests.py --check 7")

    ts = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    entry = {
        "round": args.round,
        "timestamp": ts,
        "block": args.block,
        "weight": args.weight,
        "rank": args.rank,
        "url": commit_url[:80] if commit_url else None,
        "url_reachable": url_ok,
        "url_status_code": url_code,
        "config_hash": config_hash,
        "config_changed": config_changed,
        "datalog_age_days": round(datalog_age, 1) if datalog_age is not None else None,
        "evaluate_rank": eval_rank,
        "evaluate_salience": eval_salience,
        "raw_auc_estimate": args.auc,
        "windows_since_deployment": windows_since_deploy,
    }

    # Append to registry
    registry_path = REGISTRY_DIR / "agent_registry.jsonl"
    with open(registry_path, "a") as f:
        f.write(json.dumps(entry) + "\n")

    # Append to progress.txt
    progress_path = REGISTRY_DIR / "progress.txt"
    url_str = "ok" if url_ok else f"FAIL({url_code})"
    weight_str = f"{args.weight:.6f}" if args.weight is not None else "unknown"
    rank_str = str(args.rank) if args.rank is not None else "unknown"
    config_str = "CHANGED" if config_changed else "ok"
    line = (f"[R{args.round:03d}] FAST -- weight={weight_str} rank={rank_str} "
            f"url={url_str} config={config_str} "
            f"datalog_age={f'{datalog_age:.1f}d' if datalog_age else 'unknown'} "
            f"deploy_gate={windows_since_deploy}/10\n")
    with open(progress_path, "a") as f:
        f.write(line)

    print(line.strip())

    # Window gate warning
    if windows_since_deploy < 10:
        print(f"WINDOW GATE: {windows_since_deploy}/10 fast loops since last deployment.")
        print("Slow loop is LOCKED. Do not propose mutations yet.")

    if config_changed:
        sys.exit(2)  # Signal config change to Claude Code
    if not url_ok and commit_url and "YOUR" not in commit_url:
        print(f"PAYLOAD FAILURE: commit URL returned {url_code}. Run triage Step 1.")
        sys.exit(3)  # Signal payload failure


if __name__ == "__main__":
    main()
