#!/usr/bin/env python3
"""
registry/init_registry.py

Initialises the agent registry for a new SN123 MANTIS mining session.
Run once before starting Claude Code for the first time.

Usage:
    python registry/init_registry.py
    python registry/init_registry.py --hotkey 5ABC...
"""
import argparse
import json
import os
import hashlib
from datetime import datetime, timezone
from pathlib import Path

REGISTRY_DIR = Path(__file__).parent
ROOT = REGISTRY_DIR.parent


def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def init_agent_registry():
    path = REGISTRY_DIR / "agent_registry.jsonl"
    if path.exists():
        n = len([l for l in path.read_text().split("\n") if l.strip()])
        print(f"  agent_registry.jsonl: exists ({n} entries)")
        return
    path.write_text("")
    print("  agent_registry.jsonl: created (empty)")


def init_progress(hotkey=""):
    path = REGISTRY_DIR / "progress.txt"
    if path.exists():
        print(f"  progress.txt: exists ({path.stat().st_size} bytes)")
        return
    path.write_text(
        f"# SN123 MANTIS Miner Agent Registry\n"
        f"# Initialised: {ts()}\n"
        f"# Hotkey: {hotkey or 'NOT SET -- update after wallet creation'}\n"
        f"# Format: [R{{round}}] LOOP -- details\n"
        f"# Append-only. Never delete entries.\n"
        f"\n"
        f"[R000] INIT -- Registry created. No submissions yet.\n"
        f"[R000] INIT -- Window gate: 0 fast loops since last deployment.\n"
        f"[R000] INIT -- Phase: 1 (payload validation). Run alignment checks before first submission.\n"
    )
    print("  progress.txt: created")


def init_shadow_accuracy():
    path = REGISTRY_DIR / "shadow_accuracy.json"
    if path.exists():
        print("  shadow_accuracy.json: exists")
        return
    data = {
        "_comment": "Shadow evaluator state for SN123 MANTIS. Updated after each evaluate_embeddings.py run.",
        "evaluate_embeddings_runs": [],
        "rank_history": [],
        "salience_history": [],
        "last_rank": None,
        "last_salience": None,
        "last_run_timestamp": None,
        "last_run_datalog_age_days": None,
        "rank_trend": "unknown",
        "predicted_rank_after_last_mutation": None,
        "actual_rank_after_last_mutation": None,
        "shadow_accuracy": None,
        "_note": "shadow_accuracy = 1 - abs(predicted_rank - actual_rank) / 256. Updates after each mutation outcome."
    }
    path.write_text(json.dumps(data, indent=2))
    print("  shadow_accuracy.json: created")


def init_mutations():
    path = REGISTRY_DIR / "mutations.jsonl"
    if path.exists():
        n = len([l for l in path.read_text().split("\n") if l.strip()])
        print(f"  mutations.jsonl: exists ({n} entries)")
        return
    path.write_text("")
    print("  mutations.jsonl: created (empty)")


def init_buffer_metadata():
    path = REGISTRY_DIR / "buffer_metadata.json"
    if path.exists():
        print("  buffer_metadata.json: exists")
        return
    data = {
        "_comment": "DataLog state for SN123 MANTIS. The DataLog is the MANTIS equivalent of the SN44 replay buffer.",
        "state": "NOT_DOWNLOADED",
        "last_download_timestamp": None,
        "last_download_age_days": None,
        "datalog_path": ".storage/mantis_datalog.pkl",
        "archive_url": "https://pub-879ad825983e43529792665f4f510cd6.r2.dev/datalog.db",
        "samples_at_last_evaluate": None,
        "recommended_refresh_days": 7,
        "_note": "Download fresh DataLog before every evaluate_embeddings.py run if age > 7 days."
    }
    path.write_text(json.dumps(data, indent=2))
    print("  buffer_metadata.json: created (NOT_DOWNLOADED)")


def init_last_commit_url(hotkey=""):
    path = REGISTRY_DIR / "last_commit_url.txt"
    if path.exists():
        print(f"  last_commit_url.txt: exists ({path.read_text().strip()[:60]}...)")
        return
    placeholder = f"https://YOUR-BUCKET.r2.dev/{hotkey or 'YOUR-HOTKEY-SS58'}"
    path.write_text(placeholder)
    print(f"  last_commit_url.txt: created (placeholder -- update after first R2 upload)")


def check_mantis_repo():
    mantis_path = ROOT.parent / "MANTIS"
    if mantis_path.exists():
        config_path = mantis_path / "config.py"
        eval_path = mantis_path / "evaluate_embeddings.py"
        if config_path.exists() and eval_path.exists():
            print(f"  MANTIS repo: found at {mantis_path}")
            # Hash config.py
            h = hashlib.sha256(config_path.read_bytes()).hexdigest()[:12]
            print(f"  config.py hash: {h}")
            # Store hash for CHECK 7
            hash_file = ROOT / "scoring_alignment" / ".config_hash"
            hash_file.parent.mkdir(exist_ok=True)
            hash_file.write_text(h)
            print(f"  config.py hash stored for CHECK 7")
            return True
        else:
            print(f"  MANTIS repo: found but incomplete at {mantis_path}")
    else:
        print(f"  MANTIS repo: NOT found at {mantis_path}")
        print(f"  Run: git clone https://github.com/Barbariandev/MANTIS.git {mantis_path}")
    return False


def check_alignment_tests():
    test_path = ROOT / "scoring_alignment" / "sn123_mantis_tests.py"
    if test_path.exists():
        print(f"  Alignment tests: found at {test_path}")
        return True
    # Check for the file by other name
    alt = ROOT / "scoring_alignment" / "run_all_tests.py"
    if alt.exists():
        print(f"  Alignment tests: found at {alt}")
        return True
    print(f"  Alignment tests: NOT found")
    print(f"  Copy sn123_mantis_tests.py to scoring_alignment/")
    return False


def check_generator():
    gen_path = ROOT / "generator.py"
    if gen_path.exists():
        print(f"  Generator: found at {gen_path}")
        return True
    print(f"  Generator: NOT found at {gen_path}")
    print(f"  Create generator.py with: def generate_embeddings(block: int) -> list[list[float]]")
    return False


def main():
    parser = argparse.ArgumentParser(description="Initialise SN123 MANTIS agent registry")
    parser.add_argument("--hotkey", default="", help="Your wallet hotkey ss58 address")
    args = parser.parse_args()

    print("=" * 65)
    print("SN123 MANTIS Agent Registry Initialiser")
    print("=" * 65)
    print()

    print("Checking prerequisites:")
    mantis_ok   = check_mantis_repo()
    tests_ok    = check_alignment_tests()
    gen_ok      = check_generator()
    print()

    print("Initialising registry files:")
    REGISTRY_DIR.mkdir(exist_ok=True)
    init_agent_registry()
    init_progress(args.hotkey)
    init_shadow_accuracy()
    init_mutations()
    init_buffer_metadata()
    init_last_commit_url(args.hotkey)
    print()

    print("=" * 65)
    if mantis_ok and tests_ok:
        print("Registry ready.")
        print()
        print("Next steps:")
        print("  1. Run: python scoring_alignment/sn123_mantis_tests.py")
        print("  2. Fix any FAIL before first submission")
        print("  3. Update registry/last_commit_url.txt after first R2 upload")
        print("  4. Start Claude Code: claude")
        print()
        print("First Claude Code prompt:")
        print('  "Read CLAUDE.md and subnet_config.json, then run the')
        print('   session start checklist from CLAUDE.md Section 11."')
    else:
        print("Prerequisites missing (see above). Fix before starting Claude Code.")
    print("=" * 65)


if __name__ == "__main__":
    main()
