"""
generator.py

Template for your SN123 MANTIS embedding generator.
This is the file you iterate on -- it is the miner's "model".

CRITICAL CONTRACT (from evaluate_embeddings.py inject_synthetic_embeddings):
  - Must expose: def generate_embeddings(block: int) -> list
  - Must return exactly len(config.CHALLENGES) embeddings
  - Embedding i must have exactly config.CHALLENGES[i]['dim'] elements
  - All values must be in [-1.0, 1.0]
  - For multi-asset challenges (MULTI-BREAKOUT, XSEC-RANK): return dict {asset: value}
  - Non-zero values only -- zeros are stored but contribute no salience

Challenge order from config.py (MUST match your return order):
  [0] ETH-1H-BINARY       dim=2   weight=1.0
  [1] ETH-HITFIRST-100M   dim=3   weight=2.5
  [2] ETH-LBFGS           dim=17  weight=3.5  <-- highest single-asset weight
  [3] BTC-LBFGS-6H        dim=17  weight=2.875
  [4] CADUSD-1H-BINARY    dim=2   weight=1.0
  [5] NZDUSD-1H-BINARY    dim=2   weight=1.0
  [6] CHFUSD-1H-BINARY    dim=2   weight=1.0
  [7] XAGUSD-1H-BINARY    dim=2   weight=1.0
  [8] MULTI-BREAKOUT       dict    weight=5.0  <-- HIGHEST weight
  [9] XSEC-RANK            dict    weight=3.0

Run alignment checks before every submission:
  python scoring_alignment/sn123_mantis_tests.py

Test locally before deploying:
  cd /path/to/MANTIS && python evaluate_embeddings.py --generator /path/to/generator.py --days 7
"""
from __future__ import annotations
import random
import math

# Import config from the MANTIS repo if available
try:
    import sys, os
    MANTIS_PATH = os.environ.get("MANTIS_REPO_PATH",
                                  os.path.join(os.path.dirname(__file__), "..", "MANTIS"))
    sys.path.insert(0, MANTIS_PATH)
    import config
    CHALLENGES = config.CHALLENGES
    BREAKOUT_ASSETS = config.BREAKOUT_ASSETS
except ImportError:
    # Fallback if MANTIS not in path -- update this list from config.py
    CHALLENGES = []
    BREAKOUT_ASSETS = [
        "BTC", "ETH", "XRP", "SOL", "TRX", "DOGE", "ADA", "BCH", "XMR",
        "LINK", "LEO", "HYPE", "XLM", "ZEC", "SUI", "LTC", "AVAX", "HBAR", "SHIB",
        "TON", "CRO", "DOT", "UNI", "MNT", "BGB", "TAO", "AAVE", "PEPE",
        "NEAR", "ICP", "ETC", "ONDO", "SKY"
    ]


def _predict_binary(block: int, ticker: str) -> list[float]:
    """
    Returns [direction, confidence] both in [-1, 1].
    direction > 0 = predict up, < 0 = predict down
    confidence magnitude = strength of prediction

    REPLACE THIS: implement your actual price prediction model here.
    This placeholder uses a seeded random walk -- it is above noise floor
    only by luck. Real implementations use price history, technical
    indicators, or ML models.
    """
    rng = random.Random(hash((block, ticker)) % (2**32))
    direction = rng.uniform(-0.8, 0.8)
    confidence = rng.uniform(0.1, 0.9) * (1 if direction > 0 else -1)
    return [direction, confidence]


def _predict_hitfirst(block: int, ticker: str) -> list[float]:
    """
    Returns [up_prob, down_prob, neither_prob] where values are scores
    (not required to sum to 1 -- the validator normalises).
    All values in [-1, 1].
    """
    rng = random.Random(hash((block, ticker, "hf")) % (2**32))
    return [rng.uniform(-0.5, 0.8), rng.uniform(-0.5, 0.8), rng.uniform(-0.3, 0.5)]


def _predict_lbfgs(block: int, ticker: str) -> list[float]:
    """
    Returns 17-float LBFGS embedding:
      [0]   = p: direction score in [-1, 1]
      [1:17] = Q: 16-element flattened confidence matrix, values in [-1, 1]

    See lbfgs_guide.md for the full specification of what the validator
    expects from p and Q. The salience function reads them separately.

    REPLACE THIS: implement your LBFGS embedding correctly.
    Wrong Q structure (e.g. all zeros or random) will produce low salience
    even if p is correct.
    """
    rng = random.Random(hash((block, ticker, "lbfgs")) % (2**32))
    p = rng.uniform(-0.6, 0.6)
    Q = [rng.uniform(-0.4, 0.4) for _ in range(16)]
    return [p] + Q


def _predict_multi_breakout(block: int, assets: list[str]) -> dict[str, list[float]]:
    """
    Returns {asset: [up_score, down_score]} for all assets.
    Values in [-1, 1].

    MULTI-BREAKOUT has weight=5.0 -- the highest of any challenge.
    Getting this right is the single highest-value improvement.

    The challenge asks: given the current range, which assets will break
    out upward vs downward within the range_lookback_blocks window?
    """
    rng = random.Random(hash((block, "multibreakout")) % (2**32))
    result = {}
    for asset in assets:
        up = rng.uniform(-0.6, 0.8)
        down = rng.uniform(-0.6, 0.8)
        result[asset] = [up, down]
    return result


def _predict_xsec_rank(block: int, assets: list[str]) -> dict[str, float]:
    """
    Returns {asset: rank_score} for all assets.
    Higher score = predict higher cross-sectional return.
    Values in [-1, 1].

    XSEC-RANK asks: which assets will outperform/underperform their peers
    over the next 1200 blocks (~4 hours)?

    The validator ranks assets by your scores and compares to realised
    cross-sectional returns. Cross-sectional signals (momentum, mean
    reversion, relative value) are naturally uncorrelated with directional
    signals used by most miners.
    """
    rng = random.Random(hash((block, "xsecrank")) % (2**32))
    return {asset: rng.uniform(-0.8, 0.8) for asset in assets}


def generate_embeddings(block: int) -> list:
    """
    Main entry point. Called by evaluate_embeddings.py with the current block.
    Must return exactly len(config.CHALLENGES) items in challenge order.

    DO NOT change the order or length of this list.
    DO NOT return None or empty lists for any challenge.
    """
    embeddings = []

    for challenge in CHALLENGES:
        ticker = challenge["ticker"]
        dim = challenge["dim"]
        loss_func = challenge.get("loss_func", "binary")
        assets = challenge.get("assets")

        if loss_func == "binary":
            emb = _predict_binary(block, ticker)

        elif loss_func == "hitfirst":
            emb = _predict_hitfirst(block, ticker)

        elif loss_func == "lbfgs":
            emb = _predict_lbfgs(block, ticker)

        elif loss_func == "range_breakout_multi":
            # Multi-asset: return dict, not list
            emb = _predict_multi_breakout(block, assets or BREAKOUT_ASSETS)

        elif loss_func == "xsec_rank":
            # Multi-asset: return dict, not list
            emb = _predict_xsec_rank(block, assets or BREAKOUT_ASSETS)

        else:
            # Unknown loss function -- return zeros (will not earn salience)
            # Update this when new challenge types are added to config.py
            if assets:
                emb = {a: [0.0] * dim for a in assets}
            else:
                emb = [0.0] * dim

        embeddings.append(emb)

    return embeddings


# ── Validation helpers ────────────────────────────────────────────────────────
def _validate(block: int = 0) -> bool:
    """
    Quick local validation. Run before every submission.
    For full alignment checks: python scoring_alignment/sn123_mantis_tests.py
    """
    embeddings = generate_embeddings(block)

    if len(embeddings) != len(CHALLENGES):
        print(f"FAIL: expected {len(CHALLENGES)} embeddings, got {len(embeddings)}")
        return False

    for i, (emb, challenge) in enumerate(zip(embeddings, CHALLENGES)):
        name = challenge.get("name", f"challenge_{i}")
        dim = challenge["dim"]
        assets = challenge.get("assets")
        loss_func = challenge.get("loss_func", "binary")

        if assets:
            # Multi-asset: dict
            if not isinstance(emb, dict):
                print(f"FAIL {name}: expected dict for multi-asset, got {type(emb)}")
                return False
            for asset, val in emb.items():
                if loss_func == "xsec_rank":
                    if not isinstance(val, (int, float)):
                        print(f"FAIL {name}/{asset}: expected scalar, got {type(val)}")
                        return False
                    if not -1.0 <= float(val) <= 1.0:
                        print(f"FAIL {name}/{asset}: value {val} out of [-1,1]")
                        return False
                else:
                    if len(val) != dim:
                        print(f"FAIL {name}/{asset}: expected dim={dim}, got {len(val)}")
                        return False
                    for v in val:
                        if not -1.0 <= float(v) <= 1.0:
                            print(f"FAIL {name}/{asset}: value {v} out of [-1,1]")
                            return False
        else:
            # Single-asset: list
            if not isinstance(emb, (list, tuple)) or len(emb) != dim:
                print(f"FAIL {name}: expected list of dim={dim}, got {type(emb)} len={len(emb) if hasattr(emb, '__len__') else 'N/A'}")
                return False
            if all(v == 0.0 for v in emb):
                print(f"WARN {name}: all-zero embedding -- will store but earn zero salience")
            for v in emb:
                if not -1.0 <= float(v) <= 1.0:
                    print(f"FAIL {name}: value {v} out of [-1,1]")
                    return False

    print(f"OK: all {len(CHALLENGES)} embeddings valid for block {block}")
    return True


if __name__ == "__main__":
    print("Validating generator output...")
    ok = _validate(block=0)
    import sys
    sys.exit(0 if ok else 1)
