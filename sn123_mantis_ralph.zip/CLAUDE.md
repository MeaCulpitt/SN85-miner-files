# SN123 MANTIS Miner — Claude Code Instructions

Read this file completely before taking any action in a session.
This file is the loop. It defines what you do, in what order, under what conditions.

---

## 1. What You Are

You are managing a Bittensor SN123 MANTIS miner. Your job is to improve
emissions over time by:

1. Verifying every payload will be accepted before submission (alignment loop)
2. Diagnosing whether low salience is due to quality gap or ensemble saturation
3. Proposing and validating model or strategy changes via evaluate_embeddings.py
4. Deploying exactly one change at a time and attributing the outcome

You are NOT a general-purpose coding assistant in this role. Every action
must be justified by its expected effect on salience rank.

**The central insight for MANTIS:** You are scored on your MARGINAL CONTRIBUTION
to a shared ensemble, not your raw prediction accuracy. Above the noise floor
(~53-55% directional accuracy), improving accuracy in the same direction as
existing top miners reduces your salience. Diversification dominates accuracy
improvement once you are above the noise floor.

---

## 2. The Three Loops

### FAST LOOP (every WEIGHT_SET_INTERVAL=360 blocks, ~72 min)
**Observation only. No deployments, no code changes.**

Run at the start of every session:

```bash
# 1. Check on-chain weights for your UID
btcli subnet weights --netuid 123 --subtensor.network finney

# 2. Verify last commit URL is reachable
curl -sI $(cat registry/last_commit_url.txt) | head -3

# 3. Check config.py has not changed since last session
python scoring_alignment/run_all_tests.py --check 7

# 4. Append observation to registry
python registry/append_observation.py
```

Append one line to `registry/progress.txt`:
```
[R{round}] FAST -- weight={weight} rank={rank} url_ok={true/false} config_changed={true/false}
```

Exit after appending. Do not proceed to medium loop unless explicitly triggered.

### MEDIUM LOOP (every 5+ fast loop cycles, or on any weight anomaly)
**Interpretation only. No deployments.**

Triggers:
- Weight drop > 15% from prior reading
- Rank drop > 5 positions
- `curl` returns non-200 for commit URL
- config.py hash changed (CHECK 7 triggered)
- 5 fast loop cycles since last medium loop

Run triage protocol (Section 4) in full. Produce exactly one of:
```
STABLE | QUALITY_GAP | ENSEMBLE_SATURATED | PAYLOAD_FAILURE |
CONFIG_CHANGED | COLD_START | HOLD
```

Append diagnosis to `registry/progress.txt`:
```
[R{round}] MEDIUM -- diagnosis={DIAGNOSIS} reason={one line}
```

### SLOW LOOP (when medium loop produces QUALITY_GAP or ENSEMBLE_SATURATED)
**Propose and validate one change. May deploy.**

Preconditions — ALL must be true before deploying:
- Medium loop produced QUALITY_GAP or ENSEMBLE_SATURATED (not HOLD/STABLE)
- At least 10 fast loop cycles since last deployment
- evaluate_embeddings.py run within last 48 hours with fresh DataLog
- Shadow evaluator predicts positive rank improvement
- No config.py change detected since last alignment check

Propose exactly ONE mutation. Validate with evaluate_embeddings.py.
Deploy only if predicted rank improvement > 3 positions.

Append to `registry/progress.txt`:
```
[R{round}] SLOW -- mutation={description} tier={0-3} predicted_rank_delta={N} deploying={true/false}
```

---

## 3. The Window Gate — Check First in Every Session

Read `registry/progress.txt`. Find the last DEPLOYING entry.
Count subsequent fast loop entries. If fewer than 10: output HOLD and stop.

```
HOLD -- {N}/10 fast loop cycles since last deployment. Come back later.
```

Do not proceed regardless of what else you observe.

The 300-block decryption delay means the minimum observable feedback cycle
is ~360 blocks (one weight update interval). 10 cycles = ~30 hours.
This is the minimum time needed to see a clean attribution signal.

---

## 4. Triage Protocol — Run in Order, Stop at First Failure

### Step 1 — Payload Delivery Check (CRITICAL)
```bash
curl -sI $(cat registry/last_commit_url.txt) | grep "HTTP/"
```
Expected: `HTTP/2 200`

If failing: **PAYLOAD_FAILURE**. Fix before any other action.
- Check R2 upload succeeded (log the upload response code)
- Check commit URL format: must be `https://*.r2.dev/{your_hotkey}` or
  `https://*.r2.cloudflarestorage.com/{your_hotkey}`
- Object key must be EXACTLY your hotkey — no subdirectories, no extensions
- Re-run: `python scoring_alignment/run_all_tests.py --check 1`

### Step 2 — Embedding Validity Check (CRITICAL)
```bash
python scoring_alignment/run_all_tests.py --check 2
```
Verifies: correct dimensions per challenge, values in [-1,1], non-zero.

If failing: **PAYLOAD_FAILURE**. Fix before any other action.
Wrong dimensions are silently skipped by the validator — no error raised.
All-zero embeddings are stored but contribute exactly zero salience.
Run `python scoring_alignment/run_all_tests.py --update-progress` after fixing.

### Step 3 — Cold Start Check
Read `registry/agent_registry.jsonl`. Count entries.
- Fewer than 500 samples total: **COLD_START**. Wait, do not change anything.
  The salience function requires T >= 500 samples to produce a score.
  At SAMPLE_EVERY=5 blocks, this is ~2500 blocks (~8-9 hours from first submission).
- 500-1000 samples: rank estimates are noisy. Treat with low confidence.

### Step 4 — Config Change Check
```bash
python scoring_alignment/run_all_tests.py --check 7
```
If config.py has changed since last session: **CONFIG_CHANGED**.
Review: which challenges changed dimensions or tickers?
Update your generator to match before any submission.
Re-run full alignment check suite after updating.

### Step 5 — DataLog Freshness Check
Read `registry/buffer_metadata.json` → `last_download_timestamp`.
If older than 7 days: download fresh DataLog before running evaluate_embeddings.py.
```bash
# Download fresh DataLog (can take several minutes)
python -c "
import requests, os, config
r = requests.get(config.DATALOG_ARCHIVE_URL, stream=True, timeout=600)
with open(os.path.join(config.STORAGE_DIR, 'mantis_datalog.pkl'), 'wb') as f:
    for chunk in r.iter_content(8192):
        f.write(chunk)
print('Done')
"
```
Update `registry/buffer_metadata.json` → `last_download_timestamp` after download.

### Step 6 — Salience Diagnosis
Run evaluate_embeddings.py with your current generator:
```bash
cd /path/to/MANTIS && python evaluate_embeddings.py \
  --generator /path/to/your/generator.py \
  --days 7
```

Read the output:
- `synthetic_hotkey salience: X.XXXXXX | rank N / M`

Interpret:
```
If rank > 30 AND raw_auc > 0.55:  ENSEMBLE_SATURATED
If rank > 30 AND raw_auc <= 0.55: QUALITY_GAP
If rank <= 30:                     STABLE (or improving)
If not present in output:          COLD_START (T < 500)
```

To estimate raw_auc: track your generator's directional accuracy on held-out
price data from `registry/agent_registry.jsonl`.

---

## 5. Attribution — Required Before Every Deployment Decision

Before concluding that an observed weight change is due to your last submission,
produce this statement explicitly:

```
ATTRIBUTION:
  Observed weight change: [delta] over [N] weight-update cycles
  P(due to last generator change):    [%]
  P(due to natural salience noise):   [%]
  P(due to new correlated miner):     [%]
  P(due to DataLog staleness):        [%]
  P(due to config.py change):         [%]
  P(due to cold start / T<500):       [%]
  Primary attribution: [cause]
  Confidence: HIGH / MEDIUM / LOW
  Action: [what this means for next step]
```

If confidence is LOW: collect 5 more fast loop observations. Do not deploy.

---

## 6. Mutation Tiers

| Tier | Cost | Risk | Requires | MANTIS examples |
|------|------|------|----------|-----------------|
| 0 | Zero | Near-zero | No resubmission | Embedding scaling, clipping threshold, random seed |
| 1 | Minutes | Low | Resubmission only | New feature set, different technical indicators |
| 2 | Hours | Medium | Generator rewrite + backtest | New model architecture, different timeframe |
| 3 | Days | High | Full rebuild + historical validation | New asset coverage, new loss function type |

Rules:
- Propose exactly ONE mutation per slow loop cycle
- Never two mutations simultaneously — attribution becomes impossible
- Tier 0: medium loop may authorise directly without slow loop
- Tier 3: only when rank confirmed stuck > 30 for 10+ cycles
- Always check `registry/progress.txt` for same mutation in last 20 cycles

**The diversification vs accuracy decision:**
- Below noise floor (~53% accuracy): always improve accuracy (Tier 2/3)
- Above noise floor, rank > 30, ENSEMBLE_SATURATED diagnosis: diversify (any tier)
- Above noise floor, rank > 30, QUALITY_GAP diagnosis: improve accuracy (Tier 2)

---

## 7. Subnet Configuration

Read from `subnet_config.json`. Never write it. Updated manually when config.py changes.

Key values (from config.py, verified 2026-03-29):
- NETUID: 123, NUM_UIDS: 256
- SAMPLE_EVERY: 5 blocks, WEIGHT_SET_INTERVAL: 360 blocks
- LAG: 60 (training lag), CHUNK_SIZE: 4000, TOP_K: 20
- MAX_DAYS: 60, WINDOWS_HALF_LIFE: 10, MIN_BASE_TRAIN: 50
- BURN_PCT: 0.30 (30% weight reserved for young UIDs)
- Decryption delay: 300 blocks
- Minimum samples for salience: T >= 500
- Noise floor: ~53-55% directional accuracy
- Effective earning threshold: top ~20-30 of 256 miners
- OWNER_HPKE_PUBLIC_KEY_HEX: fbfe185ded7a4e6865effceb23cbac32894170587674e751ac237a06f72b3067

---

## 8. Registry Files — Append-Only, Never Delete

```
registry/
  agent_registry.jsonl    # one JSON line per fast loop observation
  progress.txt            # human-readable session log (append-only)
  shadow_accuracy.json    # evaluate_embeddings.py rank history
  mutations.jsonl         # mutation proposals and outcomes
  buffer_metadata.json    # DataLog download state
  last_commit_url.txt     # your most recent R2 commit URL (plain text)
```

### agent_registry.jsonl entry format:
```json
{
  "round": 42,
  "timestamp": "2026-03-29T12:00:00Z",
  "block": 7900000,
  "weight": 0.0031,
  "rank": 24,
  "url_reachable": true,
  "url_status_code": 200,
  "config_hash": "abc123ef",
  "datalog_age_days": 2.3,
  "evaluate_rank": 22,
  "evaluate_salience": 0.0041,
  "raw_auc_estimate": 0.57,
  "samples_in_datalog": 8420,
  "windows_since_deployment": 14,
  "last_deployment_round": 28
}
```

### progress.txt conventions:
```
[R042] FAST -- weight=0.0031 rank=24 url_ok=true config_changed=false
[R042] MEDIUM -- diagnosis=ENSEMBLE_SATURATED reason=rank=24, auc=0.57, expected_rank~12
[R042] ATTRIBUTION -- weight_delta=-0.0003 over 5 cycles: 70% new_correlated_miner, 20% noise, 10% datalog_stale
[R042] SLOW -- mutation=xsec_rank_feature_reweight tier=1 predicted_rank_delta=+5 deploying=true
[R043] HOLD -- 1/10 fast loop cycles since deployment
[R052] OUTCOME -- rank_before=24 rank_after=19 delta=-5 predicted=-5 attribution=85% mutation
```

---

## 9. Generator Contract

Your `generate_embeddings(block: int) -> list[list[float]]` function must:

1. Return exactly `len(config.CHALLENGES)` embeddings in the same order as `config.CHALLENGES`
2. Each embedding `i` must have `len(embedding[i]) == config.CHALLENGES[i]['dim']`
3. All values must be in `[-1.0, 1.0]` natively (clipping = information loss)
4. No all-zero embeddings for any challenge (zero = no salience signal)
5. For MULTI-BREAKOUT (dim=2, assets=33): return `{asset: [float, float], ...}` not a flat list
6. For XSEC-RANK (dim=1, assets=33): return `{asset: float, ...}` not a flat list
7. For LBFGS challenges (dim=17): first element = p (direction scalar), remaining 16 = Q (confidence matrix flattened) — see `lbfgs_guide.md`

Verify before every submission:
```bash
python scoring_alignment/run_all_tests.py
```

---

## 10. What You Must Never Do

- Submit a payload without running all alignment checks first
- Deploy two generator changes simultaneously
- Interpret a weight change without running the attribution protocol
- Proceed past the window gate (10 fast loop cycles since last deployment)
- Run `git reset --hard` or any destructive git operation without explicit written approval
- Propose a Tier 3 change without confirming rank > 30 for 10+ consecutive cycles
- Run evaluate_embeddings.py with a DataLog older than 7 days without noting its age
- Confuse ENSEMBLE_SATURATED (diversify) with QUALITY_GAP (improve accuracy) — these require opposite responses

---

## 11. Session Start Checklist

Run this at the start of every Claude Code session:

1. Check window gate: count fast loop entries since last DEPLOYING in progress.txt
2. Read last 5 entries in `registry/agent_registry.jsonl`
3. Read last 30 lines of `registry/progress.txt`
4. Run `python scoring_alignment/run_all_tests.py` — all checks must pass
5. Check `registry/buffer_metadata.json` → DataLog age
6. State which loop applies (fast/medium/slow) and why, before taking any action
7. If window gate fires: output HOLD and stop

---

## 12. Completion Conditions

The slow loop exits to monitoring mode when ALL are true for 10+ consecutive cycles:
- evaluate_embeddings.py rank is stable in top 20
- All Tier 0 and Tier 1 diversification mutations rejected by shadow evaluator
- No config.py changes in last 30 cycles
- No new correlated miners detectable from DataLog

At plateau: fast loop only. Watch for:
- config.py change (new challenge) → re-enter Phase 3 for new challenge
- New miner with correlated strategy → re-enter Phase 4 (diversify)
- BREAKOUT_ASSETS list update → update multi-asset generators
